#!/bin/zsh
find . -type f | parallel "cat {} | grep leaks"
