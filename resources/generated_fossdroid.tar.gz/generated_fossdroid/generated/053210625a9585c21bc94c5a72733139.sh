#!/bin/zsh
java -Xmx${1}g -jar /home/asm140830/AndroidTA/AndroidTAEnvironment/tools/FlowDroid/soot-infoflow-cmd/target/soot-infoflow-cmd-jar-with-dependencies.jar -a ${2} -p ${3} -s /home/asm140830/AndroidTA/AndroidTAEnvironment/tools/FlowDroid/soot-infoflow-android/SourcesAndSinks.txt --aplength 5 --maxcallbackspercomponent 100 --maxcallbacksdepth -1 --pathalgo SOURCESONLY  > ${4} 2>&1
